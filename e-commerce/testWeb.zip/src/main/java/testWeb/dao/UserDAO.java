package testWeb.dao;

import testWeb.vo.*;

public interface UserDAO {
	public int queryByUserInfo (UserInfo userinfo) throws Exception;
	public void insertUserInfo (UserInfo userinfo) throws Exception;
	public int existUserInfo (UserInfo userinfo) throws Exception;
	public void nowUser(UserInfo userinfo) throws Exception;
	public void modifyUserInfo (UserInfo userinfo) throws Exception;

}
