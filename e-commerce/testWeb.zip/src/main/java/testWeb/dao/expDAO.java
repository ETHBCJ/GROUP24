package testWeb.dao;

import testWeb.vo.RobotInfo1;

public interface expDAO {

	void insertExpInfo(RobotInfo1 expinfo) throws Exception;

}
