package testWeb.dao;

import java.util.List;

import testWeb.vo.Robot;


public interface RobotMapperDao {
  
     List<Robot> all();

    List<Robot> cx(Integer id);

     int dl(int id);

     int update(Robot robot);

     int in(Robot robot);
}
