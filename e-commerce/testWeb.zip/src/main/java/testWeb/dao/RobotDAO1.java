package testWeb.dao;

import testWeb.vo.RobotInfo1;

import java.util.List;

public interface RobotDAO1 {
    List<RobotInfo1> getRobotListByUsername(String username) throws Exception;
}