package testWeb.dao.impl;

import testWeb.dao.RobotDAO1;
import testWeb.db.DBConnect;
import testWeb.vo.RobotInfo1;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RobotDAOImpl1 implements RobotDAO1 {

    @Override
    public List<RobotInfo1> getRobotListByUsername(String username) throws Exception {
        List<RobotInfo1> robotList = new ArrayList<>();

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            // 创建数据库连接
            DBConnect dbConnect = new DBConnect();
            connection = dbConnect.getConnection();

            // 准备SQL语句
            String query = "SELECT * FROM robotinfo WHERE username = ?";
            statement = connection.prepareStatement(query);
            statement.setString(1, username);

            // 执行查询
            resultSet = statement.executeQuery();

            // 处理查询结果
            while (resultSet.next()) {
                RobotInfo1 robotInfo = new RobotInfo1();
                robotInfo.setId(resultSet.getString("Id"));
       
                robotInfo.setExplorationTime(resultSet.getString("explorationtime"));
            
                robotInfo.setNumOfTreasure(resultSet.getString("numoftreasure"));
                
                robotInfo.setPicture(resultSet.getString("picture"));
             
                robotList.add(robotInfo);
            }
        } finally {
            // 关闭数据库资源
            if (resultSet != null) {
                resultSet.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (connection != null) {
                connection.close();
            }
            if (connection != null) {
                connection.close();
            }
        }

        return robotList;
    }
}
