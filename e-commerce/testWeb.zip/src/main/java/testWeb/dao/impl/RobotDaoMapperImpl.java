package testWeb.dao.impl;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import testWeb.dao.RobotMapperDao;
import testWeb.vo.Robot;


public class RobotDaoMapperImpl implements RobotMapperDao {


    @Override
    public List<Robot> all() {
        String sql = "select * from robot";
        JdbcUtil jdbc =new JdbcUtil();
        Connection conn = jdbc.getConn();
        ResultSet rs=null;
        PreparedStatement preparedStatement=null;
        List<Robot> list = new ArrayList<>();
        try {
            preparedStatement = conn.prepareStatement(sql);
            rs = preparedStatement.executeQuery();
            while (rs.next()){
                int id = rs.getInt("id");
                String ic = rs.getString("name");
                String date = rs.getString("speed");
                String program = rs.getString("characteristic");
                Robot robot = new Robot();
                robot.setId(id);
                robot.setName(ic);
                robot.setSpeed(date);
                robot.setCharacteristic(program);
                list.add(robot);
            }
            return  list;
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            jdbc.close(rs,preparedStatement,conn);
        }
        return null;
    }

    @Override
    public List<Robot> cx(Integer idS) {
        String sql = "select * from robot where id=?";
        JdbcUtil jdbc = new JdbcUtil();
        Connection conn = jdbc.getConn();
        ResultSet rs=null;
        PreparedStatement preparedStatement=null;
        List<Robot> list = new ArrayList<>();
        try {
            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1,idS);
            rs = preparedStatement.executeQuery();
            while (rs.next()){
            	 int id = rs.getInt("id");
                 String ic = rs.getString("name");
                 String date = rs.getString("speed");
                 String program = rs.getString("characteristic");
                 Robot robot = new Robot();
                 robot.setId(id);
                 robot.setName(ic);
                 robot.setSpeed(date);
                 robot.setCharacteristic(program);
                 list.add(robot);
            }
            return  list;
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            jdbc.close(rs,preparedStatement,conn);
        }
        return null;
    }

    @Override
    public int dl(int id) {
        String slq = "DELETE FROM robot WHERE id= ?";
        JdbcUtil jdbc = new JdbcUtil();

        Connection conn = null;
        PreparedStatement preparedStatement=null;
        try {
            conn=jdbc.getConn();
            preparedStatement=conn.prepareStatement(slq);
            preparedStatement.setInt(1,id);
            boolean rs= preparedStatement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                preparedStatement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return 0;
    }

    @Override
    public int update(Robot robot) {
        String slq = "update robot set name=?,speed=?,characteristic=? where id=?";
        JdbcUtil jdbc = new JdbcUtil();
        Connection conn = null;
        PreparedStatement preparedStatement=null;
        try {
            conn=jdbc.getConn();
            preparedStatement=conn.prepareStatement(slq);
           preparedStatement.setString(1,robot.getName());
           preparedStatement.setString(2,robot.getSpeed() );
           preparedStatement.setString(3,robot.getCharacteristic());
           preparedStatement.setInt(4,robot.getId());
           preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                preparedStatement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return 0;
    }

    @Override
    public int in(Robot robot) {
        String slq = "insert into robot(name,speed,characteristic) values(?,?,?)";
        JdbcUtil jdbc = new JdbcUtil();
        Connection conn = null;
        PreparedStatement preparedStatement=null;
        try {
            conn=jdbc.getConn();
            preparedStatement=conn.prepareStatement(slq);
            preparedStatement.setString(1,robot.getName());
            preparedStatement.setString(2,robot.getSpeed() );
            preparedStatement.setString(3,robot.getCharacteristic());
            int kk=preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                preparedStatement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return 0;
    }
}
