package testWeb.dao.impl;

import java.io.IOException;
import java.sql.*;
import java.util.Properties;

public class JdbcUtil {

   

    public Connection getConn() {
        Connection conn=null;
        try {
        	 try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				
			}
        	 conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/javawebdb?useUnicode=true&characterEncoding=utf8&useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true","root","123456");

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }
    public void close(ResultSet rs, Statement st,Connection connection){
        if (rs!=null){
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }finally {
                if (st!=null){
                    try {
                        st.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }finally {
                        if (connection!=null){
                            try {
                                connection.close();
                            } catch (SQLException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }
        }
    }

}

