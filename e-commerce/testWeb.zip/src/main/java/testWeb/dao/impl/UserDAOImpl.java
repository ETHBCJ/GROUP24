package testWeb.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import testWeb.dao.UserDAO;
import testWeb.db.DBConnect;
import testWeb.vo.UserInfo;


public class UserDAOImpl implements UserDAO {

	//用户登录
	@Override
	public int queryByUserInfo(UserInfo userinfo) throws Exception {
		// TODO Auto-generated method stub
		int flag = 0;
		String sql = "select * from userinfo where username=?";
		PreparedStatement pstmt = null;
		DBConnect dbc = null;
		
		try {
			dbc = new DBConnect();
			pstmt = dbc.getConnection().prepareStatement(sql);
			pstmt.setString(1, userinfo.getUsername());
			
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				if(rs.getString("password").equals(userinfo.getPassword())) {
					userinfo.setId(rs.getString("userinfoid"));
					flag = 1;
				}
			}
			rs.close();
			pstmt.close();
		}catch(SQLException e) {
		     System.out.println(e.getMessage());
	     }finally {
		     dbc.close();
	     }
	      return flag;
	}
	
	//保存现在登录的用户
		@Override
		public void nowUser(UserInfo userinfo) throws Exception {
			// TODO Auto-generated method stub
			String sql = "select * from userinfo where username=? and password=?";
			PreparedStatement pstmt = null;
			DBConnect dbc = null;
			
			try {
				dbc = new DBConnect();
				pstmt = dbc.getConnection().prepareStatement(sql);
				pstmt.setString(1, userinfo.getUsername());
				pstmt.setString(2, userinfo.getPassword());
				
				ResultSet rs = pstmt.executeQuery();
				while(rs.next()){
				
				UserInfo.setNowid(rs.getString("userinfoid"));
				UserInfo.setNowname(rs.getString("username"));
				UserInfo.setNowgender(rs.getString("gender"));
				UserInfo.setNowemail(rs.getString("email"));
				UserInfo.setNowphone(rs.getString("phone"));
				UserInfo.setNowadd(rs.getString("address"));
				UserInfo.setNowpwd(rs.getString("password"));
				}
					
				rs.close();
				pstmt.close();
			}catch(SQLException e) {
			     System.out.println(e.getMessage());
		     }finally {
			     dbc.close();
		     }
		}

	//用户注册
	@Override
	public void insertUserInfo(UserInfo userinfo) throws Exception {
		// TODO Auto-generated method stub
		String sql = "insert into userinfo values(?,?,?,?,?,?,?)";		
		PreparedStatement pstmt = null;
		DBConnect dbc = null;
		
		try {
			dbc = new DBConnect();
			pstmt = dbc.getConnection().prepareStatement("select * from userinfo");
			ResultSet rset = pstmt.executeQuery();
			int row = 0;
			while(rset.next()){row++;}
			
			pstmt = dbc.getConnection().prepareStatement(sql);
			pstmt.setInt(1, row+1);
			pstmt.setString(2, userinfo.getUsername());
			pstmt.setString(3, userinfo.getGender());
			pstmt.setString(4, userinfo.getEmail());
			pstmt.setString(5, userinfo.getPhone());
			pstmt.setString(6, userinfo.getAddress());
			pstmt.setString(7, userinfo.getPassword());
			
			pstmt.executeUpdate();
			pstmt.close();
		}catch(SQLException e) {
		    System.out.println(e.getMessage());
	    }finally {
		    dbc.close();
	    }
	}

	//依据电话或邮箱判断是否是已存在用户
	@Override
	public int existUserInfo(UserInfo userinfo) throws Exception {
		// TODO Auto-generated method stub
		int flag = 1;
		String sql = "select * from userinfo";
		PreparedStatement pstmt = null;
		DBConnect dbc = null;
		
		try {
			dbc = new DBConnect();
			pstmt = dbc.getConnection().prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				if(rs.getString("phone").equals(userinfo.getPhone())||rs.getString("email").equals(userinfo.getEmail())) {
					flag = 0;
				}
			}
			rs.close();
			pstmt.close();
		}catch(SQLException e) {
		     System.out.println(e.getMessage());
	     }finally {
		     dbc.close();
	     }
	      return flag;
	}
	

	
	
	//用户修改密码
	@Override
	public void modifyUserInfo(UserInfo userinfo) throws Exception {
		// TODO Auto-generated method stub
		String sql = "update userinfo set password=? where userinfoid=?";		
		PreparedStatement pstmt = null;
		DBConnect dbc = null;
		dbc = new DBConnect();
		
		try {
			
			pstmt = dbc.getConnection().prepareStatement(sql);

			pstmt.setString(2, userinfo.getId());
			pstmt.setString(1, userinfo.getPassword());
			
			pstmt.executeUpdate();
			pstmt.close();
		}catch(SQLException e) {
		    System.out.println(e.getMessage());
	    }finally {
		    dbc.close();
	    }
	}

}
