package testWeb.dao.impl;

import testWeb.dao.expDAO;
import testWeb.db.DBConnect;
import testWeb.vo.RobotInfo1;

import java.sql.*;

public class expDAOImpl implements expDAO {

	@Override
	public void insertExpInfo(RobotInfo1 expinfo) throws Exception {
		
	        String sql = "insert into robotinfo values(?,?,?,?,?,?)";		
			PreparedStatement pstmt = null;
			DBConnect dbc = null;
			
			try {
				dbc = new DBConnect();
				pstmt = dbc.getConnection().prepareStatement("select * from robotinfo");
				ResultSet rset = pstmt.executeQuery();
				int row = 0;
				while(rset.next()){row++;}
				
				pstmt = dbc.getConnection().prepareStatement(sql);
				pstmt.setInt(1, row+1);
				pstmt.setString(2, expinfo.getExplorationTime());
				pstmt.setString(3, expinfo.getNumOfTreasure());
				pstmt.setString(4, expinfo.getUsername());
				pstmt.setString(5, expinfo.getPicture());
				pstmt.setString(6, expinfo.getUserid());
				
				pstmt.executeUpdate();
				pstmt.close();
			}catch(SQLException e) {
			    System.out.println(e.getMessage());
		    }finally {
			    dbc.close();
		    }
	}

}
