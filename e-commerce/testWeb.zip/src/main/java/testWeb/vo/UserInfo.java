package testWeb.vo;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UserInfo {
	
	private String username;
	private String password;
	private String email;
	private String address;
	private String phone;
	private String gender;
	private String id;
	
	private static String nowname;
	private static String nowpwd;
	private static String nowemail;
	private static String nowadd;
	private static String nowphone;
	private static String nowgender;
	private static String nowid;
	
	
	
	public static String getNowname() {
		return nowname;
	}
	public static void setNowname(String nowname) {
		UserInfo.nowname = nowname;
	}
	public static String getNowpwd() {
		return nowpwd;
	}
	public static void setNowpwd(String nowpwd) {
		UserInfo.nowpwd = nowpwd;
	}
	public static String getNowemail() {
		return nowemail;
	}
	public static void setNowemail(String nowemail) {
		UserInfo.nowemail = nowemail;
	}
	public static String getNowadd() {
		return nowadd;
	}
	public static void setNowadd(String nowadd) {
		UserInfo.nowadd = nowadd;
	}
	public static String getNowphone() {
		return nowphone;
	}
	public static void setNowphone(String nowphone) {
		UserInfo.nowphone = nowphone;
	}
	public static String getNowgender() {
		return nowgender;
	}
	public static void setNowgender(String nowgender) {
		UserInfo.nowgender = nowgender;
	}
	public static String getNowid() {
		return nowid;
	}
	public static void setNowid(String nowid) {
		UserInfo.nowid = nowid;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public int phonefm(String str){
		if(str.length()==11) {
			for (int i=0;i<str.length();i++){
				if (!(Character.isDigit(str.charAt(i)))){
					return 0;
				}
			}
			return 1;
		}else return 0;
	}
	
	public int pwdfm(String str){
		if (!(str.length()>=3&&str.length()<=16)){
				return 0;
		}
		return 1;
	}
	
	public int emailfm(String email){     
	    String str="^([a-zA-Z0-9]*[-_]?[a-zA-Z0-9]+)*@([a-zA-Z0-9]*[-_]?[a-zA-Z0-9]+)+[\\.][A-Za-z]{2,3}([\\.][A-Za-z]{2})?$";
	       Pattern p = Pattern.compile(str);     
	       Matcher m = p.matcher(email); 
	       if(m.matches()) {
	    	   return 1; 
	       } else return 0;
	   }
	
}
