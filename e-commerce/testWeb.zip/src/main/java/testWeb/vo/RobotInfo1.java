package testWeb.vo;

public class RobotInfo1 {
	private String explorationtime;
    private String numoftreasure;
    private String id;
    private String username;
    private String picture;
    private String userid;
    
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id=id;
    }
    public String getExplorationTime() {
        return explorationtime;
    }
    public void setExplorationTime(String explorationtime) {
        this.explorationtime=explorationtime;
    }
    public String getNumOfTreasure() {
        return numoftreasure;
    }
    public void setNumOfTreasure(String numoftreasure) {
        this.numoftreasure=numoftreasure;
    }
	public void setUsername(String username) {
		this.username=username;
	}
	public String getUsername() {
        return username;
    }
	
	public String getPicture() {
        return picture;
    }
    public void setPicture(String picture) {
        this.picture=picture;
    }
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
}
