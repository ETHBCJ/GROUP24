package testWeb.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import testWeb.vo.*;
import testWeb.dao.UserDAO;
import testWeb.dao.impl.*;

public class UserRegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException{
		
	}
		
	public void doPost(HttpServletRequest req, HttpServletResponse res)throws IOException, ServletException{
		UserInfo userinfo = new UserInfo();
		userinfo.setUsername(req.getParameter("username"));
		userinfo.setPassword(req.getParameter("password"));
		userinfo.setEmail(req.getParameter("email"));
		userinfo.setPhone(req.getParameter("phone"));
		userinfo.setAddress(req.getParameter("address"));
		userinfo.setGender(req.getParameter("gender"));
		String cfPwd=req.getParameter("confirm password");
				
		UserDAO dao = new UserDAOImpl();
		try {
			if(dao.existUserInfo(userinfo)==1) {
				if(userinfo.phonefm(userinfo.getPhone())+userinfo.emailfm(userinfo.getEmail())+userinfo.pwdfm(userinfo.getPassword())==3&&userinfo.getPassword().equals(cfPwd)) {
					dao.insertUserInfo(userinfo);
					res.getWriter();
					res.sendRedirect("./regSuc.jsp");
				}else {
					res.sendRedirect("./regErr.jsp");
				}
			}else if(dao.existUserInfo(userinfo)==0){
				res.sendRedirect("./regExi.jsp");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
