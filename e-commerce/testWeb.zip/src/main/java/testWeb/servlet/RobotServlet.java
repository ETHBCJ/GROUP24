package testWeb.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import testWeb.dao.RobotMapperDao;
import testWeb.dao.impl.RobotDaoMapperImpl;

import java.io.IOException;
import java.sql.Date;
import java.util.List;

@WebServlet("/robot")
public class RobotServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	RobotMapperDao robotdao = new RobotDaoMapperImpl();
        req.setAttribute("user", robotdao.all());
        req.getRequestDispatcher("/robot.jsp").forward(req,resp);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	RobotMapperDao robotdao = new RobotDaoMapperImpl();
         req.setAttribute("user", robotdao.all());
         req.getRequestDispatcher("/robot.jsp").forward(req,resp);

    }
}
