package testWeb.servlet;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import testWeb.vo.*;
import testWeb.dao.expDAO;
import testWeb.dao.impl.*;

public class expServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException{
		
	}
		
	public void doPost(HttpServletRequest req, HttpServletResponse res)throws IOException, ServletException{
		RobotInfo1 expinfo = new RobotInfo1();
		
		expinfo.setId(req.getParameter("id"));
		expinfo.setExplorationTime(req.getParameter("explorationtime"));
		expinfo.setNumOfTreasure(req.getParameter("numoftreasure"));
		expinfo.setUsername(req.getParameter("username"));
		expinfo.setPicture(req.getParameter("picture"));
		expinfo.setUserid(req.getParameter("userid"));
				
		expDAO dao = new expDAOImpl();
		try {
			dao.insertExpInfo(expinfo);
			res.getWriter();
			res.sendRedirect("./save.jsp");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
