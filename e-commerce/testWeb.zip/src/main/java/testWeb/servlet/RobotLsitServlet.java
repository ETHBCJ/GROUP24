package testWeb.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import testWeb.dao.RobotMapperDao;
import testWeb.dao.impl.RobotDaoMapperImpl;
import testWeb.vo.Robot;

import java.io.IOException;
import java.sql.Date;
import java.util.List;

@WebServlet("/user")
public class RobotLsitServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	RobotMapperDao robotdao = new RobotDaoMapperImpl();
     
        String cmd = req.getParameter("cmd");
        if ("in1".equals(cmd)){
        	String name = req.getParameter("name");
            String speed = req.getParameter("speed");
            String characteristic = req.getParameter("characteristic");
            Robot robot = new Robot();
            robot.setName(name);
            robot.setSpeed(speed);
            robot.setCharacteristic(characteristic);
            robotdao.in(robot);
        }else if ("update".equals(cmd)){
            int id = Integer.parseInt(req.getParameter("id"));
        	String name = req.getParameter("name");
            String speed = req.getParameter("speed");
            String characteristic = req.getParameter("characteristic");
            Robot robot = new Robot();
            robot.setName(name);
            robot.setSpeed(speed);
            robot.setCharacteristic(characteristic);
            robot.setId(id);
            robotdao.update(robot);
        }
        req.setAttribute("user", robotdao.all());

        if ("cx".equals(cmd)){
        	String ic = req.getParameter("id");
        	List<Robot> cx=null;
        	if(ic == null || "".equals(ic)) {
        		cx =  robotdao.all();
        	}else {
        		cx = robotdao.cx( Integer.parseInt(ic));
        	}
            req.setAttribute("user", cx);
        }
        req.getRequestDispatcher("/robot.jsp").forward(req,resp);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	RobotMapperDao robotdao = new RobotDaoMapperImpl();
     
        String id = req.getParameter("id");
        String cmd = req.getParameter("cmd");

       if ("dl".equals(cmd)){
            int id1= Integer.parseInt(id);
            robotdao.dl(id1);
            req.setAttribute("user",robotdao.all());
            req.getRequestDispatcher("/robot.jsp").forward(req,resp);
        }else if ("in".equals(cmd)){
            req.getRequestDispatcher("/robotin.jsp").forward(req,resp);
        }else if ("update".equals(cmd)){
            int ic = Integer.parseInt(req.getParameter("ic"));
            List<Robot> cx = robotdao.cx(ic);
            req.setAttribute("update",cx);
            req.getRequestDispatcher("/updaterobot.jsp").forward(req,resp);
        }

    }
}
