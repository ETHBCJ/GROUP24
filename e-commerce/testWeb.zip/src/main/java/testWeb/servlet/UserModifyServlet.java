package testWeb.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import testWeb.dao.UserDAO;
import testWeb.dao.impl.UserDAOImpl;
import testWeb.vo.UserInfo;

public class UserModifyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException{
		
	}
		
	public void doPost(HttpServletRequest req, HttpServletResponse res)throws IOException, ServletException{
		UserInfo userinfo = new UserInfo();
		
		UserDAO dao = new UserDAOImpl();
		try {
			userinfo.setId(req.getParameter("id"));
			userinfo.setPassword(req.getParameter("password"));
			String cfPwd=req.getParameter("confirm password");

			if(userinfo.pwdfm(userinfo.getPassword())==1&&userinfo.getPassword().equals(cfPwd)&&userinfo.getId().equals(UserInfo.getNowid())) {
				dao.modifyUserInfo(userinfo);;
				res.getWriter().write("password");;
				res.sendRedirect("./modSuc.jsp");
			}else {
				res.sendRedirect("./modErr.jsp");
			}	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
