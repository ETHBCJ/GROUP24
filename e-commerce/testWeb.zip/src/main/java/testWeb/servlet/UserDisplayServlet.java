package testWeb.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import testWeb.dao.UserDAO;
import testWeb.dao.impl.UserDAOImpl;
import testWeb.vo.UserInfo;

public class UserDisplayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public void doGet(HttpServletRequest req,HttpServletResponse res)
			throws IOException,ServletException{
			}
		
		public void doPost(HttpServletRequest req, HttpServletResponse res)
				throws IOException, ServletException{
			UserInfo userinfo = new UserInfo();
			UserDAO dao = new UserDAOImpl();
			
			try {
				dao.nowUser(userinfo);
				HttpSession session = req.getSession();
				session.setAttribute("id", UserInfo.getNowid());
				session.setAttribute("username", UserInfo.getNowname());
				session.setAttribute("gender", UserInfo.getNowgender());
				session.setAttribute("email", UserInfo.getNowemail());
				session.setAttribute("phone", UserInfo.getNowphone());
				session.setAttribute("address", UserInfo.getNowadd());
				
				req.getRequestDispatcher("/displayUserInfo.jsp").forward(req, res);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

}
