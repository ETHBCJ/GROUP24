package testWeb.servlet;

import java.io.IOException;

import java.util.List;

import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import testWeb.dao.RobotDAO1;
import testWeb.vo.RobotInfo1;
import testWeb.dao.impl.RobotDAOImpl1;

public class RobotInfoServlet1 extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest req, HttpServletResponse res)
            throws IOException, ServletException {
        doPost(req, res);
    }

    public void doPost(HttpServletRequest req, HttpServletResponse res)
            throws IOException, ServletException {
        HttpSession session = req.getSession();
        String username = (String) session.getAttribute("username");

        RobotDAO1 robotDAO = new RobotDAOImpl1();
        List<RobotInfo1> robotList = null;
        try {
            robotList = robotDAO.getRobotListByUsername(username);
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (robotList != null) {
            req.setAttribute("robotList", robotList);
            req.getRequestDispatcher("/robotinfo.jsp").forward(req, res);
        } else {
            res.sendRedirect("./error.jsp");
        }
    }
}

